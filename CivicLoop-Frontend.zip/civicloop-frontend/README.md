# CivicLoop — Frontend Demo

A responsive, frontend-only CivicLoop prototype built with React, Vite and JavaScript.

## Included

- Citizen, department and administrator demo portals
- Role-based navigation (demo-only)
- Citizen issue reporting with image preview and map location selection
- Complaint list, filters, detail pages and activity timeline
- Community support actions
- Department status updates and citizen resolution verification/reopening
- Department performance and public accountability dashboards
- Leaflet + OpenStreetMap maps
- Recharts visualizations
- Browser `localStorage` persistence for demo interactions

## Not included (intentionally)

This is **frontend only**. There is no Express backend, Supabase database, Supabase Auth, Supabase Storage, PostGIS query, real OTP/email verification, server-side authorization or real department routing. Demo login does not authenticate credentials. Browser localStorage is not secure storage and must not be used for production data.

## Run in GitHub Codespaces

1. Extract this ZIP into your Codespace workspace.
2. Open the project folder in the terminal.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the development server:

   ```bash
   npm run dev
   ```

5. Open the forwarded port shown by Codespaces (Vite defaults to `5173`).

## Demo access

On the login screen, select a role. Any email/password is accepted; the role determines the portal.

- Citizen: `citizen@civicloop.demo`
- Department: `department@civicloop.demo`
- Admin: `admin@civicloop.demo`
- Password: any value (for example `demo123`)

## Reset demo data

Open browser developer tools → Application → Local Storage → delete keys beginning with `civicloop_`, then refresh.

## Project structure

```text
civicloop-frontend/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── src/
    ├── App.jsx
    ├── components.jsx
    ├── data.js
    ├── store.jsx
    ├── main.jsx
    └── styles.css
```

## Notes

- Leaflet map tiles require an internet connection.
- The demo uses illustrative seed records and image URLs.
- The report form stores uploaded image previews as browser object URLs; they are not uploaded to cloud storage.
- The nearby-duplicate hint is a lightweight frontend approximation, not a PostGIS distance query.
- Performance scores and monthly chart data are illustrative demo values.
