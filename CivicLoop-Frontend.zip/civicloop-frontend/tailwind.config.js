/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { colors: { civic: { 50: '#eff8f4', 100: '#d9eee4', 500: '#23866c', 700: '#17624f', 900: '#123d35' } } } },
  plugins: [],
}
