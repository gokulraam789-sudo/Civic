import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { demoUsers, initialComplaints } from './data'

const StoreContext = createContext(null)
export function StoreProvider({ children }) {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('civicloop_user') || 'null'))
  const [complaints, setComplaints] = useState(() => JSON.parse(localStorage.getItem('civicloop_complaints') || 'null') || initialComplaints)
  const [supported, setSupported] = useState(() => JSON.parse(localStorage.getItem('civicloop_supported') || '[]'))
  useEffect(() => localStorage.setItem('civicloop_user', JSON.stringify(user)), [user])
  useEffect(() => localStorage.setItem('civicloop_complaints', JSON.stringify(complaints)), [complaints])
  useEffect(() => localStorage.setItem('civicloop_supported', JSON.stringify(supported)), [supported])
  const login = (role) => setUser(demoUsers[role])
  const logout = () => setUser(null)
  const addComplaint = (payload) => {
    const item = { ...payload, id:`CIV-2026-${Math.floor(1100 + Math.random()*8900)}`, status:'Submitted', date:new Date().toISOString(), supporters:1, citizen:user?.name || 'Demo Citizen', citizenEmail:user?.email || 'citizen@civicloop.demo', updates:[{status:'Submitted',date:new Date().toISOString(),note:'Complaint submitted by citizen.'}] }
    setComplaints(prev => [item, ...prev]); return item
  }
  const updateComplaint = (id, patch, note) => setComplaints(prev => prev.map(c => c.id === id ? { ...c, ...patch, updates:[...(c.updates || []), { status:patch.status || c.status, date:new Date().toISOString(), note:note || 'Complaint updated.' }] } : c))
  const supportComplaint = (id) => {
    if (supported.includes(id)) return false
    setSupported(prev => [...prev,id]); setComplaints(prev => prev.map(c => c.id === id ? {...c,supporters:c.supporters+1} : c)); return true
  }
  const value = useMemo(() => ({user,login,logout,complaints,addComplaint,updateComplaint,supported,supportComplaint}), [user,complaints,supported])
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}
export const useStore = () => useContext(StoreContext)
