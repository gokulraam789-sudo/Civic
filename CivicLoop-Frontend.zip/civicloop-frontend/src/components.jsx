import React from 'react'
import { NavLink, useLocation, useNavigate } from 'react-router-dom'
import { Activity, AlertCircle, ArrowUpRight, Bell, CheckCircle2, ChevronDown, CircleHelp, FilePlus2, LayoutDashboard, LogOut, Map, Menu, MessageSquare, Search, ShieldCheck, Users, X, Building2, ClipboardList, BarChart3, UserRound } from 'lucide-react'
import { useStore } from './store'

export function Brand({small=false}) { return <div className="brand"><span className="brand-mark"><Activity size={20}/></span>{!small && <span>Civic<span className="brand-light">Loop</span></span>}</div> }
export function Status({status}) {
  const cls = status?.toLowerCase().replaceAll(' ','-')
  return <span className={`status status-${cls}`}>{status}</span>
}
export function PageTitle({eyebrow,title,description,action}) { return <div className="page-title"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div> }
export function StatCard({label,value,delta,icon:Icon,tone='green'}) { return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={19}/></div><div className="stat-info"><span>{label}</span><strong>{value}</strong>{delta && <small>{delta}</small>}</div></div> }
export function EmptyState({title='Nothing here yet',text='New activity will appear here.'}) { return <div className="empty-state"><div className="empty-icon"><ClipboardList size={23}/></div><b>{title}</b><p>{text}</p></div> }

const citizenNav = [
  {to:'/citizen',label:'Overview',icon:LayoutDashboard,end:true},
  {to:'/citizen/report',label:'Report an issue',icon:FilePlus2},
  {to:'/citizen/explore',label:'Explore issues',icon:Map},
  {to:'/citizen/complaints',label:'My complaints',icon:ClipboardList},
]
const deptNav = [
  {to:'/department',label:'Overview',icon:LayoutDashboard,end:true},
  {to:'/department/complaints',label:'Assigned complaints',icon:ClipboardList},
  {to:'/department/performance',label:'Performance',icon:BarChart3},
]
const adminNav = [
  {to:'/admin',label:'Overview',icon:LayoutDashboard,end:true},
  {to:'/admin/complaints',label:'All complaints',icon:ClipboardList},
  {to:'/admin/departments',label:'Departments',icon:Building2},
  {to:'/admin/public',label:'Public accountability',icon:Users},
]
export function AppShell({children}) {
  const {user,logout} = useStore()
  const [open,setOpen] = React.useState(false)
  const nav = user?.role === 'admin' ? adminNav : user?.role === 'department' ? deptNav : citizenNav
  const roleLabel = user?.role === 'admin' ? 'ADMINISTRATOR' : user?.role === 'department' ? 'DEPARTMENT PORTAL' : 'CITIZEN PORTAL'
  const navigate = useNavigate()
  const location = useLocation()
  React.useEffect(()=>setOpen(false),[location.pathname])
  return <div className="app-shell">
    <aside className={`sidebar ${open?'sidebar-open':''}`}>
      <div className="sidebar-top"><Brand/><button className="icon-button mobile-close" onClick={()=>setOpen(false)}><X size={19}/></button></div>
      <div className="portal-label">{roleLabel}</div>
      <nav className="side-nav">{nav.map(item=><NavLink key={item.to} to={item.to} end={item.end} className={({isActive})=>`nav-item ${isActive?'active':''}`}><item.icon size={18}/><span>{item.label}</span>{item.to.includes('report') && <span className="nav-plus">+</span>}</NavLink>)}</nav>
      <div className="sidebar-bottom">
        <div className="help-card"><div className="help-icon"><CircleHelp size={17}/></div><b>Need a hand?</b><p>Learn how CivicLoop keeps your community in the loop.</p><button onClick={()=>navigate('/help')}>Explore help <ArrowUpRight size={14}/></button></div>
        <div className="profile-mini"><div className="avatar">{user?.name?.slice(0,1) || 'U'}</div><div className="profile-copy"><b>{user?.name}</b><span>{user?.subtitle || user?.role}</span></div><button title="Log out" className="icon-button" onClick={()=>{logout();navigate('/')}}><LogOut size={17}/></button></div>
      </div>
    </aside>
    <div className="main-column">
      <header className="topbar"><button className="icon-button menu-trigger" onClick={()=>setOpen(true)}><Menu size={20}/></button><div className="breadcrumb">Workspace <span>/</span> <b>{location.pathname.split('/').filter(Boolean).at(-1)?.replaceAll('-',' ') || 'Overview'}</b></div><div className="top-actions"><span className="live-indicator"><i/> Demo environment</span><button className="icon-button notification" title="Notifications"><Bell size={18}/><i/></button><div className="top-avatar">{user?.name?.slice(0,1)}</div></div></header>
      <main className="content">{children}<footer className="footer"><span>© 2026 CivicLoop</span><span>Making civic action visible. <b>One report at a time.</b></span></footer></main>
    </div>
    {open && <button className="sidebar-scrim" onClick={()=>setOpen(false)} aria-label="Close navigation"/>}
  </div>
}
