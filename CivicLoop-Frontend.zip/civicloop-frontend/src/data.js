export const categories = [
  'Road Damage / Potholes', 'Garbage Accumulation', 'Drainage Problems',
  'Water Leakage', 'Streetlight Problems', 'Other Civic Issues'
]
export const departments = [
  { id: 'DPT-01', name: 'Roads & Highways', categories: ['Road Damage / Potholes'] },
  { id: 'DPT-02', name: 'Public Health & Sanitation', categories: ['Garbage Accumulation'] },
  { id: 'DPT-03', name: 'Water Supply & Drainage', categories: ['Drainage Problems', 'Water Leakage'] },
  { id: 'DPT-04', name: 'Electrical Maintenance', categories: ['Streetlight Problems'] },
  { id: 'DPT-05', name: 'General Civic Services', categories: ['Other Civic Issues'] },
]
const now = Date.now()
const ago = (days) => new Date(now - days * 86400000).toISOString()
export const initialComplaints = [
  { id:'CIV-2026-1048', category:categories[0], title:'Large pothole near the bus stop', description:'A deep pothole has formed near the main bus stop. Two-wheelers are swerving suddenly to avoid it.', location:'Avinashi Road, Peelamedu, Coimbatore', lat:11.0254, lng:77.0012, status:'In Progress', department:'Roads & Highways', date:ago(2), supporters:24, citizen:'Arun Kumar', citizenEmail:'citizen@civicloop.demo', image:'https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=900', updates:[{status:'Submitted',date:ago(2),note:'Complaint submitted by citizen.'},{status:'Assigned',date:ago(2),note:'Assigned to Roads & Highways.'},{status:'In Progress',date:ago(1),note:'Inspection team scheduled a site visit.'}] },
  { id:'CIV-2026-1047', category:categories[1], title:'Garbage overflowing at street corner', description:'Waste has not been collected for several days. The area is attracting stray animals.', location:'Gandhipuram 5th Street, Coimbatore', lat:11.0183, lng:76.9674, status:'Submitted', department:'Public Health & Sanitation', date:ago(1), supporters:18, citizen:'Priya S', citizenEmail:'citizen@civicloop.demo', image:'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=900', updates:[{status:'Submitted',date:ago(1),note:'Complaint submitted by citizen.'}] },
  { id:'CIV-2026-1046', category:categories[2], title:'Drain water spilling onto road', description:'Drainage water is overflowing and causing a bad smell near the junction.', location:'Ramanathapuram Junction, Coimbatore', lat:10.9981, lng:76.9941, status:'Under Review', department:'Water Supply & Drainage', date:ago(4), supporters:31, citizen:'Karthik R', citizenEmail:'citizen@civicloop.demo', image:'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=900', updates:[{status:'Submitted',date:ago(4),note:'Complaint submitted.'},{status:'Under Review',date:ago(3),note:'Department is reviewing the complaint.'}] },
  { id:'CIV-2026-1045', category:categories[3], title:'Continuous water leakage', description:'Clean water is leaking from a damaged pipe and flowing along the road.', location:'RS Puram, Coimbatore', lat:11.0098, lng:76.9531, status:'Resolution Submitted', department:'Water Supply & Drainage', date:ago(6), supporters:12, citizen:'Meena K', citizenEmail:'meena@example.com', image:'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=900', resolutionImage:'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=900', updates:[{status:'Submitted',date:ago(6),note:'Complaint submitted.'},{status:'In Progress',date:ago(4),note:'Repair work started.'},{status:'Resolution Submitted',date:ago(1),note:'Department submitted completion evidence.'}] },
  { id:'CIV-2026-1044', category:categories[4], title:'Streetlight not working', description:'The streetlight has not been working for a week, leaving the road dark at night.', location:'Saibaba Colony, Coimbatore', lat:11.0268, lng:76.9442, status:'Resolved', department:'Electrical Maintenance', date:ago(9), supporters:9, citizen:'Arun Kumar', citizenEmail:'citizen@civicloop.demo', image:'https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=900', resolutionImage:'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=900', updates:[{status:'Submitted',date:ago(9),note:'Complaint submitted.'},{status:'Resolved',date:ago(5),note:'Light replaced and verified.'}] },
  { id:'CIV-2026-1043', category:categories[0], title:'Damaged road surface near school', description:'The road surface is broken and unsafe for school children.', location:'Race Course, Coimbatore', lat:11.0062, lng:76.9761, status:'Reopened', department:'Roads & Highways', date:ago(12), supporters:42, citizen:'Arun Kumar', citizenEmail:'citizen@civicloop.demo', image:'https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=900', updates:[{status:'Submitted',date:ago(12),note:'Complaint submitted.'},{status:'Resolution Submitted',date:ago(7),note:'Patching work completed.'},{status:'Reopened',date:ago(3),note:'Citizen reported that the pothole remains.'}] },
]
export const demoUsers = {
  citizen: { name:'Arun Kumar', email:'citizen@civicloop.demo', role:'citizen', subtitle:'Coimbatore resident' },
  department: { name:'Department Officer', email:'department@civicloop.demo', role:'department', department:'Roads & Highways', subtitle:'Roads & Highways' },
  admin: { name:'Platform Administrator', email:'admin@civicloop.demo', role:'admin', subtitle:'CivicLoop administration' },
}
export const monthlyData = [
  {month:'Jun',reported:42,resolved:31},{month:'Jul',reported:58,resolved:45},{month:'Aug',reported:49,resolved:42},
  {month:'Sep',reported:73,resolved:56},{month:'Oct',reported:65,resolved:59},{month:'Nov',reported:38,resolved:27}
]
